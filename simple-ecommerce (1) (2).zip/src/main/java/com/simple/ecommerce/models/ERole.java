package com.simple.ecommerce.models;

public enum ERole {
  ROLE_SUPER_ADMIN,
  ROLE_ADMIN,
  ROLE_CUSTOMER
}
